from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError

CustomUser = get_user_model()

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    nickname = forms.CharField(max_length=30, required=True)
    ip_address = forms.GenericIPAddressField(protocol='both', unpack_ipv4=False, required=False)  # 필수 아님

    class Meta:
        model = CustomUser
        fields = ('email', 'nickname', 'ip_address', 'password1', 'password2')
    
    # 예외처리(이메일 중복)
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if CustomUser.objects.filter(email__iexact=email).exists():
            raise ValidationError("이미 사용 중인 이메일입니다.")
        return email
    
    # 예외처리(닉네임 중복)
    def clean_nickname(self):
        nickname = self.cleaned_data.get('nickname')
        if CustomUser.objects.filter(nickname__iexact=nickname).exists():
            raise ValidationError("이미 사용 중인 닉네임입니다.")
        return nickname
    
    def save(self, commit=True):
        user = super(CustomUserCreationForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.nickname = self.cleaned_data['nickname']
        user.ip_address = self.cleaned_data.get('ip_address')
        if commit:
            user.save()
        return user

class EmailLoginForm(AuthenticationForm):
    username = forms.EmailField(label='Email', widget=forms.EmailInput(attrs={'autofocus': True}))

    # Meta 클래스 제거
    # class Meta:
    #     model = CustomUser
    #     fields = ['email', 'password']

    def clean_username(self):
        email = self.cleaned_data.get('username')
        if not CustomUser.objects.filter(email__iexact=email).exists():
            raise ValidationError("존재하지 않는 이메일입니다.")
        return email