from django.urls import path
from . import views

app_name = 'user' # 네임스페이스 설정: 템플릿에서 URL을 네임스페이스와 함꼐 참조 할 수 있다.

urlpatterns = [
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
]